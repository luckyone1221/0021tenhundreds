=== Theme Check ===
Contributors: hoantv
Author URI: http://g5plus.net/
Plugin URL: http://smartframework.g5plus.net/
Requires at Least: 1.0
Tested Up To: 4.6.1
Tags: admin, options framework, plugin options, setting, theme options, meta-boxes setting, term-meta setting
Stable tag: 20161115

Smart Framework is a simple, truly extensible and fully responsive options framework for WordPress themes and plugins.

== Description ==
Smart Framework is a simple, truly extensible and fully responsive options framework for WordPress themes and plugins.
- 31+ Fields for meta boxes, options, term meta
- Support Row, Group, Repeater, Panel for field
- Quickly & Easy register Post Type
- Quickly & Easy register Taxonomy for Post Type
- Quickly & Easy register meta-boxes for Post Type
- Quickly & Easy register term-meta for Post Type
- Quickly & Easy build theme options, plugin option with simple configuration

== Changelog ==
= 20161115 =
* Version: 1.0
* First release.
